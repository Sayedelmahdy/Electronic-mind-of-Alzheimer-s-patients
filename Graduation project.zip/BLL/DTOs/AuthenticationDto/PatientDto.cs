﻿namespace BLL.DTOs.AuthenticationDto
{
    public class PatientDto
    {
        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public string relationality { get; set; }
    }
}