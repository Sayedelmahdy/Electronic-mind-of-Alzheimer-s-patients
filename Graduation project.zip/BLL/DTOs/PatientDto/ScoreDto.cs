﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOs.PatientDto
{
    public class ScoreDto
    {
        public int CurrentScore { get; set; }
        public int MaxScore { get; set; }
    }
}
