﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL.DTOs.CaregiverDto
{
    public class GetPatientsDto
    {
        
        public string PatientId { get; set; }
        public string PatientName { get; set;}
    }
}
